##__all__ = ['channel', 'drivencavity','Bfs', 'TaylorGreen','Lshape', 'apbl','diffusor','NSProblem']
#from NSProblem import NSProblem, parameters
#from channel import channel as NSchannel
#from drivencavity import drivencavity as NSdrivencavity
#from Bfs import Bfs as NSBfs
#from TaylorGreen import TaylorGreen
#from Lshape import Lshape as NSLshape
#from apbl import apbl as NSapbl
#from diffusor import diffusor as NSdiffusor
##from cylinder2D import cylinder2D as NScylinder2D
##from longchannel import longchannel as NSlongchannel
#from aneurysm import aneurysm as NSaneurysm
##from square_duct import square_duct as NSsquare_duct

