from NSSolver import NSSolver, solver_parameters
from NSCoupled import NSCoupled
from NSSegregated import NSSegregated
from NSFullySegregated import NSFullySegregated
#from NSCoupledR import NSCoupledR
